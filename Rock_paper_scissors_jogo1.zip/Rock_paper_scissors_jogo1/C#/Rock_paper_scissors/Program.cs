﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rock_paper_scissors
{
    class Program
    {

        static string PedirJogada()
        {
            string jogada;

            do
            {
                Console.WriteLine("Informe a opção do Jogador");
                jogada = Console.ReadLine();

                
                if (jogada.ToUpper() != "T" && jogada.ToUpper() != "P" && jogada.ToUpper() != "R")
                    Console.WriteLine("Opção inválida");

            } while (jogada.ToUpper() != "T" && jogada.ToUpper() != "P" && jogada.ToUpper() != "R");

            return jogada;
        }

        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Bem vindo ao Pedra, Papel, Tesoura");
                Console.WriteLine("P - Papel || R - Pedra || T - Tesoura\n");

                Console.WriteLine("Armando faça a sua jogada!");
                string jogada1 = PedirJogada().ToUpper();

                Console.WriteLine("Dave faça a sua jogada!");
                string jogada2 = PedirJogada().ToUpper();

                String mensagem = "Jogo empatou";

                if (jogada1 == "P" && jogada2 == "R")
                    mensagem = "Armando é o vencedor - Papel envolve Pedra";
                else if (jogada1 == "P" && jogada2 == "T")
                    mensagem = "Dave é o vencedor - Tesoura corta Papel";
                else if (jogada1 == "R" && jogada2 == "P")
                    mensagem = "Dave é o vencedor - Papel envolve Pedra";
                else if (jogada1 == "R" && jogada2 == "T")
                    mensagem = "Armando é o vencedor - Pedra quebra Tesoura";
                else if (jogada1 == "T" && jogada2 == "P")
                    mensagem = "Armando é o vencedor - Tesoura Corta Papel";
                else if (jogada1 == "T" && jogada2 == "R")
                    mensagem = "Dave é o vencedor - Pedra Quebra Tesoura";

                Console.WriteLine(mensagem);

                Console.ReadKey();
                Console.Clear();

            } while (true);
        }
    }
}
