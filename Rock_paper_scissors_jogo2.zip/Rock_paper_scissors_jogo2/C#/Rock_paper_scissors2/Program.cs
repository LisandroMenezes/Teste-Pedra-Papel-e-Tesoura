﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rock_paper_scissors
{
    class Program
    {

        static string PedirJogada(string jogada)
        {

            do
            {
                
                if (jogada.ToUpper() != "T" && jogada.ToUpper() != "P" && jogada.ToUpper() != "R")
                    Console.WriteLine("Opção inválida");

            } while (jogada.ToUpper() != "T" && jogada.ToUpper() != "P" && jogada.ToUpper() != "R");

            return jogada;
        }

        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Bem vindo ao Pedra, Papel, Tesoura");
                Console.WriteLine("P - Papel || R - Pedra || T - Tesoura\n");

                Console.WriteLine("Competidores");
                Console.WriteLine("Grupo 1 - Armando, Dave, Richard, Michael");
                Console.WriteLine("Grupo 2 - Allen, Omer, David E., Richard X.");

                Console.WriteLine("Este é um jogo eliminatório ou seja haverá apenas 1 partida por competidor!");
                Console.WriteLine("Vencedor do Grupo 1 deverá enfrentar vencedor do grupo2");
                Console.WriteLine("No final apenas 1 vencerá, boa sorte");


                int iJogadas = 0;
                string jogada1 = string.Empty;
                string jogada2 = string.Empty;
                string nomeJogador1 = string.Empty;
                string nomeJogador2 = string.Empty;
                // Grupo 1
                string nomeVencedorGrupo1Chave1 = string.Empty;
                string jogadaVencedoraGrupo1Chave1 = string.Empty;
                string nomeVencedorGrupo1Chave2 = string.Empty;
                string jogadaVencedoraGrupo1Chave2 = string.Empty;
                string nomeVencedorGrupo1 = string.Empty;
                string jogadaVencedoraGrupo1 = string.Empty;
                // Grupo 2
                string nomeVencedorGrupo2Chave1 = string.Empty;
                string jogadaVencedoraGrupo2Chave1 = string.Empty;
                string nomeVencedorGrupo2Chave2 = string.Empty;
                string jogadaVencedoraGrupo2Chave2 = string.Empty;
                string nomeVencedorGrupo2 = string.Empty;
                string jogadaVencedoraGrupo2 = string.Empty;


                // Primeira Jogada
                var TableGrupo1Chave1 = new List<Jogador>
                {
                        new Jogador() { Name="Armando", acao="P"},
                        new Jogador() { Name="Dave",  acao="T"},
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Grupo 1, Chave 1, - ", " ", TableGrupo1Chave1[0].Name, " vs ",  TableGrupo1Chave1[1].Name));

                foreach (Jogador grupo1 in TableGrupo1Chave1)
                {
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " Joga ", " ", grupo1.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo1.Name;
                        jogada1 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }else
                    {
                        nomeJogador2 = grupo1.Name;
                        jogada2 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado primeira jogada
                string VencedorChave1 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedor1 = int.Parse(VencedorChave1.Substring(0, 1));

                // Vencedor primeira jogada
                if (idVencedor1 == 1)
                {
                    nomeVencedorGrupo1Chave1 = nomeJogador1;
                    jogadaVencedoraGrupo1Chave1 = jogada1;
                }else
                {
                    nomeVencedorGrupo1Chave1 = nomeJogador2;
                    jogadaVencedoraGrupo1Chave1 = jogada2;
                }

                Console.WriteLine(string.Concat("Primeira rodada, grupo 1 ", " - ", VencedorChave1.Substring(1)));

                // Segunda Jogada
                var TableGrupo1Chave2 = new List<Jogador>
                {
                        new Jogador() { Name="Richard", acao="R"},
                        new Jogador() { Name="Michael", acao="T"}
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Grupo 1 - Chave 2 - ", " ", TableGrupo1Chave2[0].Name, " vs ", TableGrupo1Chave2[1].Name));


                iJogadas = 0;
                foreach (Jogador grupo1 in TableGrupo1Chave2)
                {
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " Joga ", " ", grupo1.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo1.Name;
                        jogada1 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupo1.Name;
                        jogada2 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado segunda jogada
                string VencedorChave2 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedor2 = int.Parse(VencedorChave2.Substring(0, 1));

                // Vencedor segunda jogada
                if (idVencedor2 == 1)
                {
                    nomeVencedorGrupo1Chave2 = nomeJogador1;
                    jogadaVencedoraGrupo1Chave2 = jogada1;
                }
                else
                {
                    nomeVencedorGrupo1Chave2 = nomeJogador2;
                    jogadaVencedoraGrupo1Chave2 = jogada2;
                }

                Console.WriteLine(string.Concat("Segunda rodada, grupo1 ", " - ", VencedorChave2.Substring(1)));

                // Jogada dos vencedores primeira e segunda rodada
                var TableGrupo1Vencedores = new List<Jogador>
                {
                        new Jogador() { Name=nomeVencedorGrupo1Chave1, acao=jogadaVencedoraGrupo1Chave1},
                        new Jogador() { Name=nomeVencedorGrupo1Chave2, acao=jogadaVencedoraGrupo1Chave2}
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Jogada dos vencedores Grupo1 - ", " ", TableGrupo1Vencedores[0].Name, " vs ", TableGrupo1Vencedores[1].Name));

                // Jogada dos vencedores
                iJogadas = 0;
                foreach (Jogador grupo1 in TableGrupo1Vencedores)
                {
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo1.Name, " ", " Joga ", " ", grupo1.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo1.Name;
                        jogada1 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupo1.Name;
                        jogada2 = PedirJogada(grupo1.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado Final Grupo1
                string VencedorGrupo1 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedorGrupo1 = int.Parse(VencedorGrupo1.Substring(0, 1));

                // Campeão Grupo 1
                if (idVencedorGrupo1 == 1)
                {
                    nomeVencedorGrupo1 = nomeJogador1;
                    jogadaVencedoraGrupo1 = jogada1;
                }
                else
                {
                    nomeVencedorGrupo1 = nomeJogador2;
                    jogadaVencedoraGrupo1 = jogada2;
                }

                Console.WriteLine(string.Concat("Vencedor grupo1 ", " - ", VencedorGrupo1.Substring(1)));

                ////// jogadas GRUPO 2

                // Primeira Jogada GRUPO 2
                var TableGrupo2Chave1 = new List<Jogador>
                {
                        new Jogador() { Name="Allen", acao="T"},
                        new Jogador() { Name="Omer",  acao="P"},
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Grupo2, Chave 1 - ", " ", TableGrupo2Chave1[0].Name, " vs ", TableGrupo2Chave1[1].Name));

                iJogadas = 0;
                foreach (Jogador grupo2 in TableGrupo2Chave1)
                {
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " Joga ", " ", grupo2.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo2.Name;
                        jogada1 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupo2.Name;
                        jogada2 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado primeira jogada
                string VencedorChave1Grupo2 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedorChave1Grupo2 = int.Parse(VencedorChave1Grupo2.Substring(0, 1));

                // Vencedor primeira jogada
                if (idVencedorChave1Grupo2 == 1)
                {
                    nomeVencedorGrupo2Chave1 = nomeJogador1;
                    jogadaVencedoraGrupo2Chave1 = jogada1;
                }
                else
                {
                    nomeVencedorGrupo2Chave1 = nomeJogador2;
                    jogadaVencedoraGrupo2Chave1 = jogada2;
                }

                Console.WriteLine(string.Concat("Primeira rodada, grupo2 ", " - ", VencedorChave1Grupo2.Substring(1)));

                // Segunda Jogada
                var TableGrupo2Chave2 = new List<Jogador>
                {
                        new Jogador() { Name="David E.", acao="R"},
                        new Jogador() { Name="Richard X.", acao="P"}
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Grupo2, Chave 2 - ", " ", TableGrupo2Chave2[0].Name, " vs ", TableGrupo2Chave2[1].Name));

                iJogadas = 0;
                foreach (Jogador grupo2 in TableGrupo2Chave2)
                {
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " Joga ", " ", grupo2.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo2.Name;
                        jogada1 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupo2.Name;
                        jogada2 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado segunda jogada
                string VencedorGrupo2Chave2 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedorGrupo2Chave2 = int.Parse(VencedorGrupo2Chave2.Substring(0, 1));

                // Vencedor segunda jogada
                if (idVencedorGrupo2Chave2 == 1)
                {
                    nomeVencedorGrupo2Chave2 = nomeJogador1;
                    jogadaVencedoraGrupo2Chave2 = jogada1;
                }
                else
                {
                    nomeVencedorGrupo2Chave2 = nomeJogador2;
                    jogadaVencedoraGrupo2Chave2 = jogada2;
                }

                Console.WriteLine(string.Concat("Segunda rodada, grupo2 ", " - ", VencedorGrupo2Chave2.Substring(1)));

                // Jogada dos vencedores primeira e segunda rodada
                var TableGrupo2Vencedores = new List<Jogador>
                {
                        new Jogador() { Name=nomeVencedorGrupo2Chave1, acao=jogadaVencedoraGrupo2Chave1},
                        new Jogador() { Name=nomeVencedorGrupo2Chave2, acao=jogadaVencedoraGrupo2Chave2}
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Vencedores Grupo2 - ", " ", TableGrupo2Vencedores[0].Name, " vs ", TableGrupo2Vencedores[1].Name));

                // Jogada dos vencedores
                iJogadas = 0;
                foreach (Jogador grupo2 in TableGrupo2Vencedores)
                {
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupo2.Name, " ", " Joga ", " ", grupo2.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupo2.Name;
                        jogada1 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupo2.Name;
                        jogada2 = PedirJogada(grupo2.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado Final Grupo1
                string VencedorGrupo2 = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                int idVencedorGrupo2 = int.Parse(VencedorGrupo2.Substring(0, 1));

                // Campeão Grupo 1
                if (idVencedorGrupo2 == 1)
                {
                    nomeVencedorGrupo2 = nomeJogador1;
                    jogadaVencedoraGrupo2 = jogada1;
                }
                else
                {
                    nomeVencedorGrupo2 = nomeJogador2;
                    jogadaVencedoraGrupo2 = jogada2;
                }

                Console.WriteLine(string.Concat("Vencedor grupo2 ", " - ", VencedorGrupo2.Substring(1)));

                
                //////// Campeão Grupo 1 Contra Compeão Grupo 2 ////////

                // Jogada dos Campeões
                var TableCampeoes = new List<Jogador>
                {
                        new Jogador() { Name=nomeVencedorGrupo1, acao=jogadaVencedoraGrupo1},
                        new Jogador() { Name=nomeVencedorGrupo2, acao=jogadaVencedoraGrupo2}
                };

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("Campeão Grupo 2 Contra Compeão Grupo 1 - ", " ", TableCampeoes[0].Name, " vs ", TableCampeoes[1].Name));

                // Jogada dos vencedores
                iJogadas = 0;
                foreach (Jogador grupoCampeao in TableCampeoes)
                {
                    Console.WriteLine(string.Concat(grupoCampeao.Name, " ", " faça a sua jogada!"));
                    Console.WriteLine(string.Concat(grupoCampeao.Name, " ", " Joga ", " ", grupoCampeao.acao));

                    if (iJogadas == 0)
                    {
                        nomeJogador1 = grupoCampeao.Name;
                        jogada1 = PedirJogada(grupoCampeao.acao.ToUpper()).ToUpper();
                    }
                    else
                    {
                        nomeJogador2 = grupoCampeao.Name;
                        jogada2 = PedirJogada(grupoCampeao.acao.ToUpper()).ToUpper();
                    }
                    iJogadas++;
                }

                // Resultado Final Grupo1
                string nomeCampeao = DefineVencedorJogadas(nomeJogador1, nomeJogador2, jogada1, jogada2);

                Console.WriteLine("--");
                Console.WriteLine("--");
                Console.WriteLine(string.Concat("---- PARABÉNS ----" ));
                Console.WriteLine(string.Concat("E O CAMPEÃO É ", " - ", nomeCampeao.Substring(1)));
                Console.WriteLine(string.Concat("------------------------------------"));


                Console.ReadKey();
                Console.Clear();

            } while (true);
        }

        static string tipoAcao(string sTipoAcao)
        {
            string descTipo = string.Empty;
            switch (sTipoAcao)
              {
                case "T":
                    descTipo = "Tesoura";
                    break;
                case "R":
                    descTipo = "Pedra";
                    break;
                case "P":
                    descTipo = "Papel";
                    break;
            }

            return descTipo;
        }

        public class Jogador
        {
            public string Name { get; set; }
            public string acao { get; set; }
        }

        static string DefineVencedorJogadas(string nomeJogador1, string nomeJogador2, string jogada1, string jogada2)
        {

            String mensagem = "Jogo empatou";

            if (jogada1 == "P" && jogada2 == "R")
                mensagem = string.Concat("1", nomeJogador1, " ", " é o vencedor - Papel envolve Pedra");
            else if (jogada1 == "P" && jogada2 == "T")
                mensagem = string.Concat("2", nomeJogador2, " ", "é o vencedor - Tesoura corta Papel");
            else if (jogada1 == "R" && jogada2 == "P")
                mensagem = string.Concat("2", nomeJogador2, " ", " é o vencedor - Papel envolve Pedra");
            else if (jogada1 == "R" && jogada2 == "T")
                mensagem = string.Concat("1", nomeJogador1, " ", " é o vencedor - Pedra quebra Tesoura");
            else if (jogada1 == "T" && jogada2 == "P")
                mensagem = string.Concat("1", nomeJogador1, " ", " é o vencedor - Tesoura Corta Papel");
            else if (jogada1 == "T" && jogada2 == "R")
                mensagem = string.Concat("2", nomeJogador2, " ", " é o vencedor - Pedra Quebra Tesoura");

            return mensagem;
        }
    }
}
